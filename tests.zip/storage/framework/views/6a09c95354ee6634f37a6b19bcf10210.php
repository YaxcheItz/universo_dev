<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH C:\Users\yaxti\Documents\MI LAP 2\ESCUELA\SEPTIMO SEMESTRE\PROGRAMACION WEB\UNIDAD 4\PRACTICA 3\PAGINADEV_LARAVEL\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/subcopy.blade.php ENDPATH**/ ?>