<?php echo e($slot); ?>

<?php /**PATH C:\Users\yaxti\Documents\MI LAP 2\ESCUELA\SEPTIMO SEMESTRE\PROGRAMACION WEB\UNIDAD 4\PRACTICA 3\PAGINADEV_LARAVEL\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>