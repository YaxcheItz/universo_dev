<div class="card p-6 flex flex-col items-start justify-between">
    <p class="text-universo-text-muted text-sm"><?php echo e($title); ?></p>
    <p class="text-universo-text text-3xl font-bold mt-2"><?php echo e($value); ?></p>
    <div class="ml-auto mt-4">
        <svg class="w-8 h-8 <?php echo e($iconColor ?? 'text-universo-purple'); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <?php echo $icon; ?>

        </svg>
    </div>
</div><?php /**PATH C:\Users\yaxti\Documents\MI LAP 2\ESCUELA\SEPTIMO SEMESTRE\PROGRAMACION WEB\UNIDAD 4\PRACTICA 3\PAGINADEV_LARAVEL\resources\views/components/stat-card.blade.php ENDPATH**/ ?>